#!/usr/bin/env python3

""" Utilities when working with JSON policies used for scenario testing."""

import json

from what_if.param_utils import create_date_range

def read_json_filters(file_path):
  """Utility function for reading JSON-formatted filters."""
  with open(file_path, "r", encoding="utf-8") as file:
    datefile = json.load(file)
    return datefile["filters"]


def apply_filters(file_path):
  """Applies constrains from a JSON-formatted filters."""
  # Read filters from JSON file
  filters_json = read_json_filters(file_path)

  # Extract dates and flex_days from JSON filters
  base_date_from = filters_json["date_from"][0]
  base_date_to = filters_json["date_to"][0]
  flex_days = filters_json["flex_days"]

  # Calculate date ranges
  applied_filters = {
    "date_from": create_date_range(base_date_from, -flex_days),
    "date_to": create_date_range(base_date_to, flex_days),
  }
  return applied_filters
